setTimeout(function loader() {
     $(document).ready(function() {
          $("#loader").css("visibility", "hidden");
          $("#loader").css("opacity", "0");
          $("#wrapper-1").css("visibility", "visible");
          $("#wrapper-1").css("opacity", "1");

     });
}, 2000);

function openSlideMenu() {
     document.getElementById('side-menu').style.width = '385px';
     document.getElementById('main').style.marginLeft = '385px';
}

function closeSlideMenu() {
     document.getElementById('side-menu').style.width = '0';
     document.getElementById('main').style.marginLeft = '0';
}

$("#location").click(function getLocation() {

     if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(function(position) {
               pos = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude,
               }
               var xhr = new XMLHttpRequest();
               xhr.open("GET", "http://api.openweathermap.org/data/2.5/forecast/daily?lat=" + pos.lat + "&lon=" + pos.lng + "&mode=xml&units=metric&APPID=4c77e0cece8bc723a06d68840986db3f", false);
               xhr.send();
               xmlDocument = xhr.responseXML;
               var min = [];
               var max = [];
               var uri;
               var d = new Date();
               today = d.getDay();
               locname = xmlDocument.getElementsByTagName("name")[0];
               loc = locname.childNodes[0];
               countryName = xmlDocument.getElementsByTagName("country")[0];
               country = countryName.childNodes[0];
               for (i = 0; i < 6; i++) {

                    x = xmlDocument.getElementsByTagName("temperature")[i];
                    min[i] = x.getAttribute("min");
                    max[i] = x.getAttribute("max");

                    x = xmlDocument.getElementsByTagName("symbol")[i];
                    weathertype = x.getAttribute("number");

                    if (weathertype > 199 && weathertype < 233) {
                         uri = "assets/img/thunderstorm.png";
                    } else if (weathertype > 299 && weathertype < 322) {
                         uri = "assets/img/many-clouds.png";
                    } else if (weathertype > 499 && weathertype < 505) {
                         uri = "assets/img/light-rain.png";
                    } else if (weathertype > 505 && weathertype < 532) {
                         uri = "assets/img/rain.png";
                    } else if (weathertype > 599 && weathertype < 623) {
                         uri = "assets/img/snow.png";
                    } else if (weathertype == 800) {
                         uri = "assets/img/sun.png";
                    } else if (weathertype == 801) {
                         uri = "assets/img/semi-cloud.png";
                    } else if (weathertype > 801 && weathertype < 805) {
                         uri = "assets/img/cloud.png";
                    }
                    var the_day = "#day" + i;
                    var the_day_img = the_day + "-img";
                    var the_day_max = the_day + "-max";
                    var the_day_min = the_day + "-min";
                    var that_day = "";
                    if (today == 0) {
                         that_day = "SUN";
                    } else if (today == 1) {
                         that_day = "MON";
                    } else if (today == 2) {
                         that_day = "TUE";
                    } else if (today == 3) {
                         that_day = "WED";
                    } else if (today == 4) {
                         that_day = "THU";
                    } else if (today == 5) {
                         that_day = "FRI";
                    } else {
                         that_day = "SAT";
                    }
                    if (today < 6) {
                         today += 1;
                    } else {
                         today = 0;
                    }
                    if (i == 0) {
                         $("#today-img").attr("src", uri);
                         $(the_day_max).html(max[i] + "&#8451;");
                         $(the_day_min).html(min[i] + "&#8451;");
                    } else {
                         $(the_day).html(that_day);
                         $(the_day_img).attr("src", uri);
                         $(the_day_max).html(max[i] + "&#8451;");
                         $(the_day_min).html(min[i] + "&#8451;");
                    }


               }
               $("#city").html(loc);
               $("#country").html(country);
          })
     }
     $(document).ready(function() {
          $("body").css("background-color", "#a970ff");
          $(".favorite").css("display", "inherit");
          $(".umbrella-top").attr("src", "assets/img/umbrella-p.png");
          $("#form").css("visibility", "hidden");
          $("#form").css("opacity", "0");
          $("#wrapper-2").css("visibility", "visible");
          $("#wrapper-2").css("opacity", "1");
     });

});

$("#search").click(function getLocation() {
     q = $("#city-input").val();

               var xhr = new XMLHttpRequest();
               xhr.open("GET", "http://api.openweathermap.org/data/2.5/forecast/daily?q="+q+"&mode=xml&units=metric&APPID=4c77e0cece8bc723a06d68840986db3f", false);
               xhr.send();
               console.log(xhr.statusText);
               xmlDocument = xhr.responseXML;
               console.log(xmlDocument);
               var min = [];
               var max = [];
               var uri;
               var d = new Date();
               today = d.getDay();
               locname = xmlDocument.getElementsByTagName("name")[0];
               loc = locname.childNodes[0];
               countryName = xmlDocument.getElementsByTagName("country")[0];
               country = countryName.childNodes[0];
               for (i = 0; i < 6; i++) {

                    x = xmlDocument.getElementsByTagName("temperature")[i];
                    min[i] = x.getAttribute("min");
                    max[i] = x.getAttribute("max");

                    x = xmlDocument.getElementsByTagName("symbol")[i];
                    weathertype = x.getAttribute("number");

                    if (weathertype > 199 && weathertype < 233) {
                         uri = "assets/img/thunderstorm.png";
                    } else if (weathertype > 299 && weathertype < 322) {
                         uri = "assets/img/many-clouds.png";
                    } else if (weathertype > 499 && weathertype < 505) {
                         uri = "assets/img/light-rain.png";
                    } else if (weathertype > 505 && weathertype < 532) {
                         uri = "assets/img/rain.png";
                    } else if (weathertype > 599 && weathertype < 623) {
                         uri = "assets/img/snow.png";
                    } else if (weathertype == 800) {
                         uri = "assets/img/sun.png";
                    } else if (weathertype == 801) {
                         uri = "assets/img/semi-cloud.png";
                    } else if (weathertype > 801 && weathertype < 805) {
                         uri = "assets/img/cloud.png";
                    }
                    var the_day = "#day" + i;
                    var the_day_img = the_day + "-img";
                    var the_day_max = the_day + "-max";
                    var the_day_min = the_day + "-min";
                    var that_day = "";
                    if (today == 0) {
                         that_day = "SUN";
                    } else if (today == 1) {
                         that_day = "MON";
                    } else if (today == 2) {
                         that_day = "TUE";
                    } else if (today == 3) {
                         that_day = "WED";
                    } else if (today == 4) {
                         that_day = "THU";
                    } else if (today == 5) {
                         that_day = "FRI";
                    } else {
                         that_day = "SAT";
                    }
                    if (today < 6) {
                         today += 1;
                    } else {
                         today = 0;
                    }
                    if (i == 0) {
                         $("#today-img").attr("src", uri);
                         $(the_day_max).html(max[i] + "&#8451;");
                         $(the_day_min).html(min[i] + "&#8451;");
                    } else {
                         $(the_day).html(that_day);
                         $(the_day_img).attr("src", uri);
                         $(the_day_max).html(max[i] + "&#8451;");
                         $(the_day_min).html(min[i] + "&#8451;");
                    }


               }
               $("#city").html(loc);
               $("#country").html(country);
          

     $(document).ready(function() {
          $("body").css("background-color", "#a970ff");
          $(".favorite").css("display", "inherit");
          $(".umbrella-top").attr("src", "assets/img/umbrella-p.png");
          $("#form").css("visibility", "hidden");
          $("#form").css("opacity", "0");
          $("#wrapper-2").css("visibility", "visible");
          $("#wrapper-2").css("opacity", "1");
     });

});
